window.KaporAIExt = window.KaporAIExt || {};

window.KaporAIExt.CONFIG = {
  KAPOR_AI_BASE_URL: 'https://beta.kapor.ai'  
};