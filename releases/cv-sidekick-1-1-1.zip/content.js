// content.js
// Initialize the extension
window.KaporAIExt.main.runMain();
window.KaporAIExt.events.initializeEventListeners();
