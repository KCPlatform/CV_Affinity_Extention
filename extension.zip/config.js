const CONFIG = {
    KAPOR_AI_BASE_URL: 'https://beta.kapor.ai',
};